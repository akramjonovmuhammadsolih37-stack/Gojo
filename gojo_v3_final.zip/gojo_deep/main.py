#!/usr/bin/env python3
"""
GOJO-USERBOT — Asosiy fayl
Yangi plugin qo'shish uchun: zeus/ papkasiga .py fayl qo'ying!
"""
import sys, os, importlib, glob, asyncio, inspect

# Panel loglarini real-time ko'rsatish
class PanelLogger:
    def __init__(self, stream):
        self.stream = stream
    def write(self, msg):
        if msg.strip():
            self.stream.write(msg)
            self.stream.flush()
    def flush(self):
        self.stream.flush()

sys.stdout = PanelLogger(sys.__stdout__)
sys.stderr = PanelLogger(sys.__stderr__)

# Render'da bot o'chib qolmasligi uchun keep-alive
try:
    from keep_alive import keep_alive
    keep_alive()
    print("[OK] Keep-alive server ishga tushdi!")
except Exception as e:
    print(f"[INFO] Keep-alive yo'q: {e}")

# ─────────────────────────────────────────
import zeus.client
client = zeus.client.client

# ─────────────────────────────────────────
# AVTOMATIK PLUGIN LOADER
# ─────────────────────────────────────────

SKIP_FILES = {"client.py", "__init__.py", "magic.py", "emojify.py"}

plugin_files = sorted(glob.glob(os.path.join(os.path.dirname(__file__), "zeus", "*.py")))

loaded = []
failed = []

for filepath in plugin_files:
    filename = os.path.basename(filepath)
    if filename in SKIP_FILES:
        continue

    module_name = f"zeus.{filename[:-3]}"
    try:
        module = importlib.import_module(module_name)

        # 1) HANDLERS ro'yxati bo'lsa qo'sh
        if hasattr(module, "HANDLERS"):
            for handler in module.HANDLERS:
                client.add_event_handler(handler)
        else:
            # 2) Modulning barcha funksiyalarini tekshir — @events.register belgilangan bo'lsa qo'sh
            count = 0
            for name, obj in inspect.getmembers(module, inspect.iscoroutinefunction):
                if hasattr(obj, "_events"):
                    for event in obj._events:
                        client.add_event_handler(obj, event)
                    count += 1

        loaded.append(filename)
        print(f"[OK] Plugin yuklandi: {filename}")
    except Exception as e:
        failed.append(filename)
        print(f"[XATO] Plugin yuklanmadi: {filename} — {e}")

print(f"\n[INFO] Jami: {len(loaded)} plugin yuklandi, {len(failed)} xato")
if failed:
    print(f"[XATO] Yuklanmagan pluginlar: {', '.join(failed)}")

print("[OK] GOJO-USERBOT ishga tushdi!\n")

async def startup_animation(client):
    """Botga ulangach Saved Messages ga animatsiya yuborish"""
    me = await client.get_me()
    chat = await client.get_input_entity("me")

    frames = [
        "⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛",
        "🟦⬛⬛⬛⬛⬛⬛⬛⬛⬛",
        "🟦🟦⬛⬛⬛⬛⬛⬛⬛⬛",
        "🟦🟦🟦⬛⬛⬛⬛⬛⬛⬛",
        "🟦🟦🟦🟦⬛⬛⬛⬛⬛⬛",
        "🟦🟦🟦🟦🟦⬛⬛⬛⬛⬛",
        "🟦🟦🟦🟦🟦🟦⬛⬛⬛⬛",
        "🟦🟦🟦🟦🟦🟦🟦⬛⬛⬛",
        "🟦🟦🟦🟦🟦🟦🟦🟦⬛⬛",
        "🟦🟦🟦🟦🟦🟦🟦🟦🟦⬛",
        "🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦",
    ]

    msg = await client.send_message("me", "⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛\n`Yuklanmoqda...`")
    for frame in frames:
        await asyncio.sleep(0.4)
        await msg.edit(f"{frame}\n`Yuklanmoqda...`")

    await asyncio.sleep(0.5)

    bot_name = os.environ.get("BOT_NAME", "GOJO Userbot")
    username = f"@{me.username}" if me.username else str(me.id)

    final_text = (
        f"✅ **{bot_name}** muvaffaqiyatli ishga tushirildi!\n\n"
        f"👤 **Foydalanuvchi:** {username}\n"
        f"🔌 **Yuklangan pluginlar:** {len(loaded)}\n"
        f"❌ **Xato pluginlar:** {len(failed)}\n\n"
        f"⚡️ Barcha buyruqlar tayyor!\n"
        f"📖 `.help` — buyruqlar ro'yxati"
    )

    # Neon animatsiya
    neon_frames = [
        "⚡️⚡️⚡️⚡️⚡️⚡️⚡️⚡️⚡️⚡️",
        "✨🌟✨🌟✨🌟✨🌟✨🌟",
        "💎💠💎💠💎💠💎💠💎💠",
    ]
    for nf in neon_frames:
        await msg.edit(nf)
        await asyncio.sleep(0.3)

    await msg.edit(final_text)

async def main():
    await client.start()
    print("[OK] Telegram ga ulandi. Buyruqlar tayyor.")
    try:
        await startup_animation(client)
    except Exception as e:
        print(f"[INFO] Startup animatsiya xatosi: {e}")
    await client.run_until_disconnected()

asyncio.run(main())
